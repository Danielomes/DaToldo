let select = document.querySelector('#pais'); 

// Sempre que a tag select for alterada, dispara uma arrow function
select.addEventListener('change', (event) => {
  tagQueVaiAlterarBackground = document.querySelector('#tagID'); //Substituir por sua tag
  if(event.target.value == 'M') {
    document.body.style.backgroundImage = "url('https://static.wixstatic.com/media/368834_fe09ceaea3ac4992b8d81bfed572de23~mv2.png/v1/fit/w_768%2Ch_768%2Cal_c%2Cq_80,enc_auto/file.jpg')"; //Substituir por sua tag
  } else if(event.target.value == 'V') {
    document.body.style.backgroundImage = "url('https://pbs.twimg.com/media/EXHXmHYXYAAhEpU.jpg')"; //Substituir por sua tag
    document.body.style.color = "white"
  }
  else if(event.target.value == 'S') {
    document.body.style.backgroundImage = "url('https://i.pinimg.com/736x/5e/26/dd/5e26ddb96ca1a43ab5ff0ee312bf6a39.jpg')"; //Substituir por sua tag
    document.body.style.color = "white"
    
  }
  else if(event.target.value == 'E') {
    document.body.style.backgroundImage = "url('https://i1.sndcdn.com/artworks-ZTykgIlA6ndPXLDt-FHwgaw-t240x240.jpg')"; //Substituir por sua tag
    document.body.style.color = "white"
    
  }
  else if(event.target.value == 'L') {
    document.body.style.backgroundImage = "url('https://rvideos1.memedroid.com/videos/UPLOADED677/63cd7a5836888.webp')"; //Substituir por sua tag
    document.body.style.color = "white"
    
  }
})
  